/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author A1961
 */
public class Cart implements Serializable
{
    private ArrayList<Item> items;

    public Cart() {
        this.items = new ArrayList();
    }

    public ArrayList<Item> getItems() {
        return items;
    }

    public void addItem(Item item)
    {
        this.items.add(item);
    }

    public void removeItem(String itemNumber)
    {
      for (Item item: items) 
      {
        if (item.getItemNumber().equals(itemNumber))
        {
          this.items.remove(item);
          break;
        }
      }
    }
    
    public int sizeCart()
    {
        return items.size();
    }
    
    public double grandTotal()
    {
        double Total = 0.0;
        for (Item item: items) 
      {
         Total += item.getPrice();
      }
        return Total;
    }
    
    
    
}
